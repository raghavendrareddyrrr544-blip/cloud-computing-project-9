// ========================================
// ONLINE VOTING SYSTEM
// ========================================


// Selected candidate

let selectedCandidate = "";


// Vote counts

let votes = {

    Priya: 0,

    Rahul: 0,

    Anjali: 0

};


// ========================================
// SELECT CANDIDATE
// ========================================

function selectCandidate(candidate) {

    selectedCandidate = candidate;

    document.getElementById(
        "selectedCandidate"
    ).innerText =
        "Selected Candidate: " + candidate;

}


// ========================================
// SUBMIT VOTE
// ========================================

function submitVote() {

    // Get voter details

    let voterName =
        document.getElementById(
            "voterName"
        ).value.trim();


    let voterId =
        document.getElementById(
            "voterId"
        ).value.trim();


    // Check name

    if (voterName === "") {

        alert("Please enter your name.");

        return;
    }


    // Check ID

    if (voterId === "") {

        alert("Please enter your Student ID.");

        return;
    }


    // Check candidate

    if (selectedCandidate === "") {

        alert("Please select a candidate.");

        return;
    }


    // Check if voter already voted

    let votedStudents =
        JSON.parse(
            localStorage.getItem(
                "votedStudents"
            )
        ) || [];


    if (votedStudents.includes(voterId)) {

        alert(
            "You have already voted!"
        );

        return;
    }


    // Add vote

    votes[selectedCandidate]++;


    // Store voter ID

    votedStudents.push(voterId);


    localStorage.setItem(
        "votedStudents",
        JSON.stringify(votedStudents)
    );


    // Store votes

    localStorage.setItem(
        "votes",
        JSON.stringify(votes)
    );


    // Success message

    document.getElementById(
        "message"
    ).innerText =
        "✅ Your vote has been submitted successfully!";


    // Clear inputs

    document.getElementById(
        "voterName"
    ).value = "";


    document.getElementById(
        "voterId"
    ).value = "";


    selectedCandidate = "";


    document.getElementById(
        "selectedCandidate"
    ).innerText =
        "No candidate selected";


    // Update results

    displayResults();

}


// ========================================
// DISPLAY RESULTS
// ========================================

function displayResults() {

    let totalVotes =
        votes.Priya +
        votes.Rahul +
        votes.Anjali;


    document.getElementById(
        "priyaVotes"
    ).innerText =
        votes.Priya;


    document.getElementById(
        "rahulVotes"
    ).innerText =
        votes.Rahul;


    document.getElementById(
        "anjaliVotes"
    ).innerText =
        votes.Anjali;


    // Calculate percentages

    if (totalVotes === 0) {

        document.getElementById(
            "priyaBar"
        ).style.width = "0%";


        document.getElementById(
            "rahulBar"
        ).style.width = "0%";


        document.getElementById(
            "anjaliBar"
        ).style.width = "0%";

        return;
    }


    let priyaPercentage =
        (votes.Priya / totalVotes) * 100;


    let rahulPercentage =
        (votes.Rahul / totalVotes) * 100;


    let anjaliPercentage =
        (votes.Anjali / totalVotes) * 100;


    document.getElementById(
        "priyaBar"
    ).style.width =
        priyaPercentage + "%";


    document.getElementById(
        "rahulBar"
    ).style.width =
        rahulPercentage + "%";


    document.getElementById(
        "anjaliBar"
    ).style.width =
        anjaliPercentage + "%";

}


// ========================================
// RESET ELECTION
// ========================================

function resetElection() {

    let confirmation =
        confirm(
            "Are you sure you want to reset the election?"
        );


    if (!confirmation) {

        return;

    }


    votes = {

        Priya: 0,

        Rahul: 0,

        Anjali: 0

    };


    localStorage.removeItem(
        "votes"
    );


    localStorage.removeItem(
        "votedStudents"
    );


    displayResults();


    document.getElementById(
        "message"
    ).innerText =
        "Election has been reset.";

}


// ========================================
// LOAD SAVED DATA
// ========================================

function loadData() {

    let savedVotes =
        localStorage.getItem(
            "votes"
        );


    if (savedVotes) {

        votes =
            JSON.parse(savedVotes);

    }


    displayResults();

}


// Start application

loadData();